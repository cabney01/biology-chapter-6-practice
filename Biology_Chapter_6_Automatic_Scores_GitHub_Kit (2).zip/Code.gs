/** Biology Chapter 6 practice — Google Apps Script, bound to the scores spreadsheet. */
const SHEET_NAME = 'Attempts';
const OPEN_DATE = '2026-10-12';
const CLOSE_DATE = '2026-10-14';
const TZ = 'America/New_York';
function doPost(e) {
  try {
    const p = JSON.parse((e.postData && e.postData.contents) || '{}');
    const date = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
    if (date < OPEN_DATE || date > CLOSE_DATE) return output({ok:false,message:'Outside practice window'});
    const name = String(p.name || '').trim().replace(/[\r\n\t]/g,' ').slice(0,100);
    const section = String(p.section || '').trim().replace(/[\r\n\t]/g,' ').slice(0,60);
    const correct = Number(p.correct), total = Number(p.total);
    if (!name || !section || !Number.isInteger(correct) || !Number.isInteger(total) || total !== 20 || correct < 0 || correct > total) return output({ok:false,message:'Invalid attempt'});
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      let sh = ss.getSheetByName(SHEET_NAME);
      if (!sh) { sh = ss.insertSheet(SHEET_NAME); sh.appendRow(['Timestamp (Eastern)','Student name','Class/block','Correct','Total','Percent','Attempt ID']); sh.setFrozenRows(1); }
      const attemptId = String(p.attemptId || '').slice(0,100);
      if (attemptId && sh.getLastRow()>1) {
        const ids = sh.getRange(2,7,sh.getLastRow()-1,1).getValues().flat();
        if (ids.includes(attemptId)) return output({ok:true,message:'Already received'});
      }
      // Prefix formula-trigger characters so student names cannot inject spreadsheet formulas.
      const safe = s => /^[=+@-]/.test(s) ? "'"+s : s;
      sh.appendRow([Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss'),safe(name),safe(section),correct,total,Math.round(correct/total*100),attemptId]);
    } finally {lock.releaseLock();}
    return output({ok:true,message:'Recorded'});
  } catch(err) {return output({ok:false,message:String(err)});}
}
function doGet() {return output({ok:true,message:'Biology practice score collector online'});}
function output(obj) {return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
